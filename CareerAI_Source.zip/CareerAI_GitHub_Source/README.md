# CareerAI — Resume Analyzer & Job Matcher

A standalone React + Vite implementation inspired by the public purpose of your deployed Career Match website. This is a fresh recreation, **not the original private Base44 source code**.

## Features
- Responsive dashboard UI
- Paste resume and target job description
- Upload a plain-text `.txt` resume
- Skill overlap score, matched skills, missing skills, and suggestions
- Example content to test the app
- Keyword matching runs locally in the browser; no API key needed

## Run locally
1. Install Node.js LTS.
2. Extract this ZIP and open a terminal in the project folder.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local address printed by Vite (usually `http://localhost:5173`).

## Production build
Run `npm run build`. The generated site is in `dist/`.

## Upload to GitHub
Create a new repository on GitHub, extract this ZIP, and upload the project files. Do not upload `node_modules`. You can deploy the Vite app using Vercel or Netlify, or configure GitHub Pages.

## Important limitations
The score is a simple keyword-overlap demo, not a real AI model or a probability of getting hired. This starter accepts `.txt` files only; PDF/DOCX parsing and genuine AI analysis need additional implementation. Keep any future AI provider API key on a backend server, never in frontend source code or GitHub.
